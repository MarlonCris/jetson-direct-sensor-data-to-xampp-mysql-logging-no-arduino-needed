"""Mock class for Units of Measure."""


class UOM:
    """Mock class for Units of Measure."""
